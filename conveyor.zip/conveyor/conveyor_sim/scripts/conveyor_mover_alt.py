#!/usr/bin/env python3

import rospy
from gazebo_msgs.srv import SetModelState
from gazebo_msgs.msg import ModelState

def move_cube():
    rospy.init_node('conveyor_mover', anonymous=True)
    rospy.wait_for_service('/gazebo/set_model_state')
    set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)

    cube_name = "demo_cube"  # Replace with the exact name of the cube model
    table_length = 0.913  # Replace with the actual length of the table in y-direction
    cube_velocity = 0.01  # Desired velocity in m/s
    rate = rospy.Rate(10)  # Loop rate in Hz

    current_y = -table_length / 2.0  # Start position at one edge of the table

    while not rospy.is_shutdown():
        # Update cube position
        current_y += cube_velocity / rate.sleep_dur.to_sec()

        # Check if the cube has reached the edge of the table
        if current_y > table_length / 2.0:
            current_y = -table_length / 2.0  # Reset to the opposite edge

        # Define the model state
        cube_state = ModelState()
        cube_state.model_name = cube_name
        cube_state.pose.position.x = 0.6  # Assuming cube moves only along y-axis
        cube_state.pose.position.y = current_y
        cube_state.pose.position.z = 0.75  # Table height, adjust as needed
        cube_state.twist.linear.y = cube_velocity  # Velocity along y
        cube_state.reference_frame = "world"  # Reference frame for movement

        # Apply the state to the cube
        try:
            set_model_state(cube_state)
        except rospy.ServiceException as e:
            rospy.logerr(f"Service call failed: {e}")

        rate.sleep()

if __name__ == '__main__':
    try:
        move_cube()
    except rospy.ROSInterruptException:
        pass
