^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.1 (2021-03-05)
------------------

0.9.0 (2021-02-28)
------------------
* Initial noetic release
* Updates for python3 and ROS Noetic
* Updates maintainers
* Contributors: Alex Moriarty, Eric Relson, Russell Toris

0.8.2 (2019-08-06)
------------------

0.8.1 (2019-04-04)
------------------
* catkin_make only supports cmake 2.8.3 for meta-pkg (`#115 <https://github.com/fetchrobotics/fetch_ros/issues/115>`_)
* sync cmake_minimum_required: 2.8.12
* [fetch_ros] new meta-package (`#110 <https://github.com/fetchrobotics/fetch_ros/issues/110>`_)
* Contributors: Alexander Moriarty

0.8.0 (2019-02-13)
------------------
* Meta-package fetch_ros was newly added after 0.8.0
