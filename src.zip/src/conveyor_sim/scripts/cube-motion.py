#!/usr/bin/env python3
import rospy
from gazebo_msgs.srv import SetModelState
from gazebo_msgs.msg import ModelState

def move_cube():
    rospy.init_node('conveyor_mover', anonymous=True)
    
    # Wait for the service
    rospy.wait_for_service('/gazebo/set_model_state')
    set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
    
    # Configuration
    cube_name = "demo_cube"
    table_length = 2.0
    cube_velocity = 0.02  # m/s
    rate = rospy.Rate(200)  # Increased to 100 Hz for smoother motion
    
    # Initial position
    current_y = -table_length / 2.0 + 0.05 * table_length
    
    while not rospy.is_shutdown():
        # Create a new model state message
        model_state_msg = ModelState()
        model_state_msg.model_name = cube_name
        
        # Set position
        model_state_msg.pose.position.x = 0.7
        model_state_msg.pose.position.y = current_y
        model_state_msg.pose.position.z = 0.65  # Slightly higher to avoid surface interaction
        
        # Set orientation
        model_state_msg.pose.orientation.x = 0
        model_state_msg.pose.orientation.y = 0
        model_state_msg.pose.orientation.z = 0
        model_state_msg.pose.orientation.w = 1
        
        # Set velocity (this was missing in original code)
        model_state_msg.twist.linear.x = 0
        model_state_msg.twist.linear.y = cube_velocity
        model_state_msg.twist.linear.z = 0
        
        # Set reference frame
        model_state_msg.reference_frame = "world"
        
        try:
            # Use the service call instead of publishing
            set_model_state(model_state_msg)
            
            # Update position for next iteration
            current_y += cube_velocity * (1.0/50.0)  # Increment based on dt
            
            # Reset position if reached the edge
            if current_y > table_length / 2.0 - 0.05 * table_length:
                current_y = -table_length / 2.0 + 0.05 * table_length
                
        except rospy.ServiceException as e:
            rospy.logerr(f"Service call failed: {e}")
            
        rate.sleep()

if __name__ == '__main__':
    try:
        move_cube()
    except rospy.ROSInterruptException:
        pass
