FetchIt! Challenge
------------------

The first FetchIt! Challenge will take place at ICRA 2019.
This simulation environment is actively under development.

Notes:

This is actively under development.

TODO:
I've merged the montreal layout for now, but it is missing the Schunk Machine.
See:

1. https://github.com/fetchrobotics/fetch_gazebo/issues/73
2. https://github.com/fetchrobotics/fetch_gazebo/issues/61

Pull requests welcome.
