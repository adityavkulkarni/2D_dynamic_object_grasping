#!/usr/bin/env python3
import rospy
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import SetModelState, GetModelState
import math

class ConveyorController:
    def __init__(self):
        rospy.init_node('conveyor_controller')
        
        # Wait for gazebo services
        rospy.wait_for_service('/gazebo/set_model_state')
        rospy.wait_for_service('/gazebo/get_model_state')
        self.set_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
        self.get_state = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        
        # Conveyor parameters
        self.conveyor_speed = 0.1  # m/s
        self.conveyor_length = 2.0  # meters
        self.conveyor_width = 0.5   # meters
        self.conveyor_height = 0.6  # meters
        
        # List of objects to track on the conveyor
        self.tracked_objects = ["demo_cube"]  # Add more object names as needed
        
    def is_on_conveyor(self, object_pose):
        """Check if an object is on the conveyor belt"""
        x, y, z = object_pose.position.x, object_pose.position.y, object_pose.position.z
        
        # Define conveyor boundaries (assuming conveyor is centered at origin)
        x_min = -self.conveyor_width/2
        x_max = self.conveyor_width/2
        y_min = -self.conveyor_length/2
        y_max = self.conveyor_length/2
        z_min = self.conveyor_height
        z_max = self.conveyor_height + 0.1  # Some tolerance
        
        return (x_min <= x <= x_max and 
                y_min <= y <= y_max and 
                z_min <= z <= z_max)
    
    def run(self):
        rate = rospy.Rate(50)  # 50 Hz update rate
        
        while not rospy.is_shutdown():
            for object_name in self.tracked_objects:
                try:
                    # Get current object state
                    current_state = self.get_state(object_name, "world")
                    
                    # Check if object is on conveyor
                    if self.is_on_conveyor(current_state.pose):
                        # Create new state message
                        new_state = ModelState()
                        new_state.model_name = object_name
                        new_state.pose = current_state.pose
                        
                        # Apply conveyor motion
                        new_state.twist.linear.y = self.conveyor_speed
                        
                        # Reset position if object reaches end of conveyor
                        if current_state.pose.position.y > self.conveyor_length/2 - 0.1:
                            new_state.pose.position.y = -self.conveyor_length/2 + 0.1
                        
                        # Update object state
                        self.set_state(new_state)
                
                except rospy.ServiceException as e:
                    rospy.logerr(f"Service call failed: {e}")
            
            rate.sleep()

if __name__ == '__main__':
    try:
        controller = ConveyorController()
        controller.run()
    except rospy.ROSInterruptException:
        pass
