#!/usr/bin/env python3

import rospy
from gazebo_msgs.srv import SetModelState
from gazebo_msgs.msg import ModelState

def move_cube():
    rospy.init_node('conveyor_mover', anonymous=True)
    pub = rospy.Publisher('/gazebo/set_model_state', ModelState, queue_size=10)
    rospy.wait_for_service('/gazebo/set_model_state')
    set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)

    cube_name = "demo_cube"  # Replace with the exact name of the cube model
    table_length = 2.0  # Replace with the actual length of the table in y-direction
    cube_velocity = 0.01  # Desired velocity in m/s
    rate = rospy.Rate(10)  # Loop rate in Hz

    current_y = -table_length / 2.0 + 0.05 * table_length # Start position at one edge of the table

    while not rospy.is_shutdown():
        # Create a new model state message
        model_state_msg = ModelState()
        model_state_msg.model_name = cube_name
        model_state_msg.pose.position.x = 0.7
        model_state_msg.pose.position.y = current_y
        model_state_msg.pose.position.z = 0.7
        
        # Set orientation (no rotation)
        model_state_msg.pose.orientation.x = 0
        model_state_msg.pose.orientation.y = 0
        model_state_msg.pose.orientation.z = 0
        model_state_msg.pose.orientation.w = 1

        # Set reference frame
        model_state_msg.reference_frame = "world"

        try:
            # Publish the new state
            pub.publish(model_state_msg)
            
            # Increment y position for next iteration
            current_y += cube_velocity
            
            # Check if the cube has reached the edge of the table
            if current_y > table_length / 2.0 - 0.05 * table_length:
                current_y = -table_length / 2.0 + 0.05 * table_length # Reset to the opposite edge
                
        except rospy.ROSInterruptException:
            pass
            
        rate.sleep()

if __name__ == '__main__':
    try:
        move_cube()
    except rospy.ROSInterruptException:
        pass